@extends('frontend.layout.app')
@section('mainsection')


<div class="cs-hero cs-style3 cs-type1 cs-bg cs-fixed_bg cs-shape_wrap_1" data-src="assets/img/hero_bg_5.jpeg"
  id="home">
  <div class="container">
    <div class="cs-hero_text">
      <h1 class="cs-hero_title wow fadeInRight" data-wow-duration="0.8s" data-wow-delay="0.2s">Welcome to Asquare Team
        <br> India's Leading Events Brand</h1>
      <div class="cs-hero_subtitle">We are 360 degree agency showcasing our expertise</div>
      <a href="{{ url('/contact') }}" class="cs-btn cs-style1 cs-type1">
        <span>Contact</span>
        <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
            fill="currentColor" />
        </svg>
      </a>
    </div>
  </div>
  <div class="cs-hero_highlite cs-primary_color cs-accent_color cs-center">
    <img src="assets/img/asquare/logo/logomain.png" alt="Portfolio" width="120px">
    <div class="cs-round_img cs-center"><img src="assets/img/hero_img.svg" alt="Circle"></div>
  </div>
  <div class="cs-hero_social_wrap cs-left_side cs-primary_font cs-primary_color">
    <div class="cs-hero_social_title">Follow Us</div>
    <ul class="cs-hero_social_links">
      <li><a href="">Behance</a></li>
      <li><a href="">Twitter</a></li>
    </ul>
  </div>
</div>
<!-- End Hero -->
<!-- Start FunFact -->
<section>
  <div class="container">
    <div class="cs-funfact_wrap cs-type1">
      <div class="cs-funfact_shape" data-src="assets/img/funfact_shape_bg.svg"></div>
      <div class="cs-funfact_left">
        <div class="cs-funfact_heading">
          <h2>Our fun fact</h2>
          <p> Sed ut perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, totam rem
            aperiam, eaque ipsa quae ab illo inventore veritatis. </p>
        </div>
      </div>
      <div class="cs-funfact_right">
        <div class="cs-funfacts">
          <div class="cs-funfact cs-style1">
            <div class="cs-funfact_number cs-primary_font cs-semi_bold cs-primary_color">
              <span data-count-to="40" class="odometer"></span>K
            </div>
            <div class="cs-funfact_text">
              <span class="cs-accent_color">+</span>
              <p>Global Happy Clients</p>
            </div>
          </div>
          <div class="cs-funfact cs-style1">
            <div class="cs-funfact_number cs-primary_font cs-semi_bold cs-primary_color">
              <span data-count-to="50" class="odometer"></span>K
            </div>
            <div class="cs-funfact_text">
              <span class="cs-accent_color">+</span>
              <p>Project Completed</p>
            </div>
          </div>
          <div class="cs-funfact cs-style1">
            <div class="cs-funfact_number cs-primary_font cs-semi_bold cs-primary_color">
              <span data-count-to="245" class="odometer"></span>
            </div>
            <div class="cs-funfact_text">
              <span class="cs-accent_color">+</span>
              <p>Team Members</p>
            </div>
          </div>
          <div class="cs-funfact cs-style1">
            <div class="cs-funfact_number cs-primary_font cs-semi_bold cs-primary_color">
              <span data-count-to="550" class="odometer"></span>
            </div>
            <div class="cs-funfact_text">
              <span class="cs-accent_color">+</span>
              <p>Digital products</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End FunFact -->
<!-- Start Service Section -->

<!-- End Service Section -->


<section class="mt-5">
  <div class="container">
    <div class="cs-section_heading cs-style1 text-center">
      <h3 class="cs-section_subtitle">Highlights</h3>
      <h2 class="cs-section_title wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Asquare Highlights</h2>
    </div>
  </div>
  <div class="cs-height_90 cs-height_lg_45"></div>
  <div class="container">
    <div class="cs-iconbox_3_list">
      <div class="cs-hover_tab active">
        <a href="service-details.html" class="cs-iconbox cs-style3">
          <div class="cs-image_layer cs-style1 cs-size_md">
            <div class="cs-image_layer_in">
              <img src="assets/img/service_7.jpeg" alt="Image" class="w-100 cs-radius_15">
            </div>
          </div>
          <span class="cs-iconbox_icon cs-center">
            <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M29.3803 3.05172C29.4089 1.94752 28.537 1.02921 27.4328 1.00062L9.43879 0.534749C8.33459 0.506159 7.41628 1.37811 7.38769 2.48231C7.35911 3.58651 8.23106 4.50482 9.33526 4.53341L25.3299 4.94752L24.9158 20.9422C24.8872 22.0464 25.7592 22.9647 26.8634 22.9933C27.9676 23.0218 28.8859 22.1499 28.9144 21.0457L29.3803 3.05172ZM3.37714 28.5502L28.7581 4.4503L26.0039 1.54961L0.622863 25.6495L3.37714 28.5502Z"
                fill="currentColor" />
            </svg>
          </span>
          <div class="cs-iconbox_in">
            <h2 class="cs-iconbox_title">Asquare Events</h2>
            <div class="cs-iconbox_subtitle">We are specialized in Corporate Events, Award Show , Exhibition-Fair ,
              Corporate Meets , Beauty
              Pageant , Brand-Product Launch etc...</div>
          </div>
        </a>
      </div>
      <div class="cs-hover_tab">
        <a href="service-details.html" class="cs-iconbox cs-style3">
          <div class="cs-image_layer cs-style1 cs-size_md">
            <div class="cs-image_layer_in">
              <img src="assets/img/service_8.jpeg" alt="Image" class="w-100 cs-radius_15">
            </div>
          </div>
          <span class="cs-iconbox_icon cs-center">
            <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M29.3803 3.05172C29.4089 1.94752 28.537 1.02921 27.4328 1.00062L9.43879 0.534749C8.33459 0.506159 7.41628 1.37811 7.38769 2.48231C7.35911 3.58651 8.23106 4.50482 9.33526 4.53341L25.3299 4.94752L24.9158 20.9422C24.8872 22.0464 25.7592 22.9647 26.8634 22.9933C27.9676 23.0218 28.8859 22.1499 28.9144 21.0457L29.3803 3.05172ZM3.37714 28.5502L28.7581 4.4503L26.0039 1.54961L0.622863 25.6495L3.37714 28.5502Z"
                fill="currentColor" />
            </svg>
          </span>
          <div class="cs-iconbox_in">
            <h2 class="cs-iconbox_title">Asquare Films</h2>
            <div class="cs-iconbox_subtitle">Asquare Films and Entertainments is an audio visual production company
              which is
              diversified into the streams of Short films, Video Portfolios, Music Albums and other
              digital contents.</div>
          </div>
        </a>
      </div>
      <div class="cs-hover_tab">
        <a href="service-details.html" class="cs-iconbox cs-style3">
          <div class="cs-image_layer cs-style1 cs-size_md">
            <div class="cs-image_layer_in">
              <img src="assets/img/service_9.jpeg" alt="Image" class="w-100 cs-radius_15">
            </div>
          </div>
          <span href="service-details.html" class="cs-iconbox_icon cs-center">
            <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M29.3803 3.05172C29.4089 1.94752 28.537 1.02921 27.4328 1.00062L9.43879 0.534749C8.33459 0.506159 7.41628 1.37811 7.38769 2.48231C7.35911 3.58651 8.23106 4.50482 9.33526 4.53341L25.3299 4.94752L24.9158 20.9422C24.8872 22.0464 25.7592 22.9647 26.8634 22.9933C27.9676 23.0218 28.8859 22.1499 28.9144 21.0457L29.3803 3.05172ZM3.37714 28.5502L28.7581 4.4503L26.0039 1.54961L0.622863 25.6495L3.37714 28.5502Z"
                fill="currentColor" />
            </svg>
          </span>
          <div class="cs-iconbox_in">
            <h2 class="cs-iconbox_title">Asquare Wedding</h2>
            <div class="cs-iconbox_subtitle">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
              lorema doloremque laudantium, totam rem.</div>
          </div>
        </a>
      </div>
      <div class="cs-hover_tab">
        <a href="service-details.html" class="cs-iconbox cs-style3">
          <div class="cs-image_layer cs-style1 cs-size_md">
            <div class="cs-image_layer_in">
              <img src="assets/img/service_10.jpeg" alt="Image" class="w-100 cs-radius_15">
            </div>
          </div>
          <span class="cs-iconbox_icon cs-center">
            <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M29.3803 3.05172C29.4089 1.94752 28.537 1.02921 27.4328 1.00062L9.43879 0.534749C8.33459 0.506159 7.41628 1.37811 7.38769 2.48231C7.35911 3.58651 8.23106 4.50482 9.33526 4.53341L25.3299 4.94752L24.9158 20.9422C24.8872 22.0464 25.7592 22.9647 26.8634 22.9933C27.9676 23.0218 28.8859 22.1499 28.9144 21.0457L29.3803 3.05172ZM3.37714 28.5502L28.7581 4.4503L26.0039 1.54961L0.622863 25.6495L3.37714 28.5502Z"
                fill="currentColor" />
            </svg>
          </span>
          <div class="cs-iconbox_in">
            <h2 class="cs-iconbox_title">Asquare Studio</h2>
            <div class="cs-iconbox_subtitle">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
              lorema doloremque laudantium, totam rem.</div>
          </div>
        </a>
      </div>
    </div>
    <div class="cs-height_50 cs-height_lg_50"></div>
  </div>
</section>



<section>
  <div class="container">
    <div class="cs-section_heading cs-style1 text-center">
      <h3 class="cs-section_subtitle">Services</h3>
      <h2 class="cs-section_title wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">Our Services</h2>
    </div>
  </div>
</section>
<div class="cs-height_150 cs-height_lg_80"></div>
<!-- Start Project Section -->
<div class="cs-portfolio cs-style2">
  <div class="cs-gradient_shape"></div>
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="cs-portfolio_img">
          <h3 class="cs-portfolio_img_title"> Events & Communication </h3>
          <div class="cs-portfolio_img_in cs-shine_hover_1 cs-radius_5">
            <img src="assets/img/portfolio_35.jpeg" alt="Portfolio" class="cs-w100">
          </div>
        </div>
      </div>
      <div class="col-xl-5 col-lg-6 offset-xl-1">
        <div class="cs-height_0 cs-height_lg_35"></div>
        <div class="cs-section_heading cs-style1">
          <h3 class="cs-section_subtitle">Service 01</h3>
          <h2 class="cs-section_title"> Events & Communication </h2>
          <div class="cs-height_45 cs-height_lg_20"></div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae omnis dignissimos est iste a. Expedita.</p>
          <a href="portfolio-details.html" class="cs-text_btn wow fadeInLeft" data-wow-duration="0.8s"
            data-wow-delay="0.2s">
            <span>See Details</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
                fill="currentColor"></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="cs-height_100 cs-height_lg_70"></div>
<div class="cs-portfolio cs-style2 cs-type1">
  <div class="cs-gradient_shape"></div>
  <div class="container">
    <div class="row align-items-center cs-column_reverse_lg">
      <div class="col-xl-5 col-lg-6">
        <div class="cs-height_0 cs-height_lg_35"></div>
        <div class="cs-section_heading cs-style1 ">
          <h3 class="cs-section_subtitle">Service 02</h3>
          <h2 class="cs-section_title"> Film & Communications </h2>
          <div class="cs-height_45 cs-height_lg_20"></div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae omnis dignissimos est iste a. Expedita.</p>
          <a href="portfolio-details.html" class="cs-text_btn wow fadeInLeft" data-wow-duration="0.8s"
            data-wow-delay="0.2s">
            <span>See Details</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
                fill="currentColor"></path>
            </svg>
          </a>
        </div>
      </div>
      <div class="col-lg-6 offset-xl-1">
        <div class="cs-portfolio_img">
          <h3 class="cs-portfolio_img_title"> Film & Communications </h3>
          <div class="cs-portfolio_img_in cs-shine_hover_1 cs-radius_5">
            <img src="assets/img/portfolio_36.jpeg" alt="Portfolio" class="cs-w100">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="cs-height_100 cs-height_lg_70"></div>
<div class="cs-portfolio cs-style2">
  <div class="cs-gradient_shape"></div>
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="cs-portfolio_img">
          <h3 class="cs-portfolio_img_title"> Kolkata Photos </h3>
          <div class="cs-portfolio_img_in cs-shine_hover_1 cs-radius_5">
            <img src="assets/img/portfolio_37.jpeg" alt="Portfolio" class="cs-w100">
          </div>
        </div>
      </div>
      <div class="col-xl-5 col-lg-6 offset-xl-1">
        <div class="cs-height_0 cs-height_lg_35"></div>
        <div class="cs-section_heading cs-style1 ">
          <h3 class="cs-section_subtitle">Service 03</h3>
          <h2 class="cs-section_title"> Kolkata Photos </h2>
          <div class="cs-height_45 cs-height_lg_20"></div>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam aperiam hic, aspernatur ab quisquam
            consectetur!</p>
          <a href="portfolio-details.html" class="cs-text_btn wow fadeInLeft" data-wow-duration="0.8s"
            data-wow-delay="0.2s">
            <span>See Details</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
                fill="currentColor"></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="cs-height_100 cs-height_lg_70"></div>
<div class="cs-portfolio cs-style2 cs-type1">
  <div class="cs-gradient_shape"></div>
  <div class="container">
    <div class="row align-items-center cs-column_reverse_lg">
      <div class="col-xl-5 col-lg-6">
        <div class="cs-height_0 cs-height_lg_35"></div>
        <div class="cs-section_heading cs-style1 ">
          <h3 class="cs-section_subtitle">Service 04</h3>
          <h2 class="cs-section_title"> Kolkata Studios</h2>
          <div class="cs-height_45 cs-height_lg_20"></div>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum nihil vel iusto, sint impedit quae.</p>
          <a href="portfolio-details.html" class="cs-text_btn wow fadeInLeft" data-wow-duration="0.8s"
            data-wow-delay="0.2s">
            <span>See Details</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
                fill="currentColor"></path>
            </svg>
          </a>
        </div>
      </div>
      <div class="col-lg-6 offset-xl-1">
        <div class="cs-portfolio_img">
          <h3 class="cs-portfolio_img_title"> Kolkata Studios</h3>
          <div class="cs-portfolio_img_in cs-shine_hover_1 cs-radius_5">
            <img src="assets/img/portfolio_38.jpeg" alt="Portfolio" class="cs-w100">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="cs-height_145 cs-height_lg_80"></div>
<div class="cs-portfolio cs-style2">
  <div class="cs-gradient_shape"></div>
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="cs-portfolio_img">
          <h3 class="cs-portfolio_img_title"> Digital Marketing </h3>
          <div class="cs-portfolio_img_in cs-shine_hover_1 cs-radius_5">
            <img src="assets/img/portfolio_37.jpeg" alt="Portfolio" class="cs-w100">
          </div>
        </div>
      </div>
      <div class="col-xl-5 col-lg-6 offset-xl-1">
        <div class="cs-height_0 cs-height_lg_35"></div>
        <div class="cs-section_heading cs-style1 ">
          <h3 class="cs-section_subtitle">Service 05</h3>
          <h2 class="cs-section_title"> Digital Marketing</h2>
          <div class="cs-height_45 cs-height_lg_20"></div>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam aperiam hic, aspernatur ab quisquam
            consectetur!</p>
          <a href="portfolio-details.html" class="cs-text_btn wow fadeInLeft" data-wow-duration="0.8s"
            data-wow-delay="0.2s">
            <span>See Details</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5303 6.53033C25.8232 6.23744 25.8232 5.76256 25.5303 5.46967L20.7574 0.696699C20.4645 0.403806 19.9896 0.403806 19.6967 0.696699C19.4038 0.989593 19.4038 1.46447 19.6967 1.75736L23.9393 6L19.6967 10.2426C19.4038 10.5355 19.4038 11.0104 19.6967 11.3033C19.9896 11.5962 20.4645 11.5962 20.7574 11.3033L25.5303 6.53033ZM0 6.75H25V5.25H0V6.75Z"
                fill="currentColor"></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="cs-height_100 cs-height_lg_70"></div>








<!-- Start Latest Project -->

<!-- End Latest Project -->
<div class="cs-height_150 cs-height_lg_80"></div>
<!-- Start gallery Text -->


<div class="container">
  <div class="cs-portfolio_1_heading">
    <div class="cs-section_heading cs-style1">
      <h3 class="cs-section_subtitle">Portfolio</h3>
      <h2 class="cs-section_title">Asquare Portfolio</h2>
    </div>
    <div class="cs-isotop_filter cs-style1">
      <ul class="cs-mp0 cs-center">
        <li class="active">
          <a href="#" data-filter="*">All</a>
        </li>
        <li>
          <a href="#" data-filter=".wedding">Events</a>
        </li>
        <li>
          <a href="#" data-filter=".portrait">Films</a>
        </li>
        <li>
          <a href="#" data-filter=".fashion">Kolkata Photos</a>
        </li>
        <li>
          <a href="#" data-filter=".commercial">Kolkata Stuidos</a>
        </li>
        <li>
          <a href="#" data-filter=".landscape">Wedding</a>
        </li>

      </ul>
    </div>
  </div>
  <div class="cs-height_90 cs-height_lg_45"></div>
</div>
<div class="container-fluid">
  <div class="container-fluid">
    <div class="cs-isotop cs-style1 cs-isotop_col_4 cs-has_gutter_24 cs-lightgallery">
      <div class="cs-grid_sizer"></div>
      <div class="cs-isotop_item wedding landscape">
        <a href="assets/img/portfolio_21_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size1 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_21.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item portrait short_film">
        <a href="assets/img/portfolio_22_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_22.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item wedding landscape">
        <a href="assets/img/portfolio_23_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size1 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_23.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item fashion">
        <a href="assets/img/portfolio_24_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_24.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item portrait">
        <a href="assets/img/portfolio_25_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_25.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item commercial">
        <a href="assets/img/portfolio_26_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_26.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item portrait short_film">
        <a href="assets/img/portfolio_27_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_27.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item wedding">
        <a href="assets/img/portfolio_28_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size2 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_28.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item fashion short_film">
        <a href="assets/img/portfolio_29_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size1 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_29.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
      <div class="cs-isotop_item fashion commercial landscape">
        <a href="assets/img/portfolio_30_lg.jpeg" class="cs-portfolio cs-style1 cs-lightbox_item cs-size1 cs-type2">
          <div class="cs-portfolio_hover"></div>
          <span class="cs-plus"></span>
          <div class="cs-portfolio_bg cs-bg" data-src="assets/img/portfolio_30.jpeg"></div>
          <div class="cs-portfolio_info">
            <div class="cs-portfolio_info_bg cs-accent_bg"></div>
            <h2 class="cs-portfolio_title">Colorful Art Work</h2>
            <div class="cs-portfolio_subtitle">View Large</div>
          </div>
        </a>
      </div>
      <!-- .cs-isotop_item -->
    </div>
  </div>
</div>


<!-- End gallery Text -->

<!-- End Video Block -->

<!-- End Blog Section -->
<!-- End Moving Text -->
<div class="cs-moving_text_wrap cs-bold cs-primary_font">
  <div class="cs-moving_text_in">
    <div class="cs-moving_text">Our reputed world wide partners</div>
    <div class="cs-moving_text">Our reputed world wide partners</div>

  </div>

</div>
<div class="cs-height_100 cs-height_lg_70"></div>




<div class="container">
 
  <section class="customer-logos slider">
    <div class="slide"><img src="https://image.freepik.com/free-vector/luxury-letter-e-logo-design_1017-8903.jpg"></div>
    <div class="slide"><img src="http://www.webcoderskull.com/img/logo.png"></div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/3d-box-logo_1103-876.jpg"></div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/blue-tech-logo_1103-822.jpg"></div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/colors-curl-logo-template_23-2147536125.jpg">
    </div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/abstract-cross-logo_23-2147536124.jpg"></div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/football-logo-background_1195-244.jpg"></div>
    <div class="slide"><img src="https://image.freepik.com/free-vector/background-of-spots-halftone_1035-3847.jpg">
    </div>
    <div class="slide"><img
        src="https://image.freepik.com/free-vector/retro-label-on-rustic-background_82147503374.jpg"></div>
  </section>









  <!-- Start Partner Logo -->
  <!-- <div class="container">
  <div class="cs-partner_logo_wrap">
    <div class="cs-partner_logo">
      <img src="assets/img/partner_1.svg" alt="Partner" />
    </div>
    <div class="cs-partner_logo">
      <img src="assets/img/partner_2.svg" alt="Partner" />
    </div>
    <div class="cs-partner_logo">
      <img src="assets/img/partner_3.svg" alt="Partner" />
    </div>
    <div class="cs-partner_logo">
      <img src="assets/img/partner_4.svg" alt="Partner" />
    </div>
    <div class="cs-partner_logo">
      <img src="assets/img/partner_5.svg" alt="Partner" />
    </div>
  </div>
</div> -->
  <!-- End Partner Logo -->
  <div class="cs-height_130 cs-height_lg_70"></div>
  <!-- Start CTA -->
  <section>
    <div class="container">
      <div class="cs-cta cs-style1 cs-bg text-center cs-shape_wrap_1 cs-position_1" data-src="assets/img/cta_bg.jpeg">
        <div class="cs-shape_1"></div>
        <div class="cs-shape_1"></div>
        <div class="cs-shape_1"></div>
        <div class="cs-cta_in">
          <h2 class="cs-cta_title cs-semi_bold cs-m0"> Let’s disscuse make <br />something <i>cool</i> together </h2>
          <div class="cs-height_70 cs-height_lg_30"></div>
          <a href="{{url('/partner')}}" class="cs-text_btn wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
            <span>Become a Partner</span>
            <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M25.5307 6.53033C25.8236 6.23744 25.8236 5.76256 25.5307 5.46967L20.7577 0.696699C20.4648 0.403806 19.99 0.403806 19.6971 0.696699C19.4042 0.989593 19.4042 1.46447 19.6971 1.75736L23.9397 6L19.6971 10.2426C19.4042 10.5355 19.4042 11.0104 19.6971 11.3033C19.99 11.5962 20.4648 11.5962 20.7577 11.3033L25.5307 6.53033ZM0.000366211 6.75H25.0004V5.25H0.000366211V6.75Z"
                fill="currentColor" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  </section>

  @endsection