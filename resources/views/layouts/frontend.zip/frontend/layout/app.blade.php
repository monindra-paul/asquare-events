@include('frontend.common.header')
@yield('mainsection')
@include('frontend.common.footer')